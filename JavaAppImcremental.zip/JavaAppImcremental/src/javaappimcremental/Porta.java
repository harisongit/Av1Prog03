
package javaappimcremental;


public class Porta {
    private Boolean aberta;
    private String cor;
    private double dx;
    private double dy;
    private double dz;

    public Boolean getAberta() {
        return aberta;
    }

    public void setAberta(Boolean aberta) {
        this.aberta = aberta;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public double getDx() {
        return dx;
    }

    public void setDx(double dx) {
        this.dx = dx;
    }

    public double getDy() {
        return dy;
    }

    public void setDy(double dy) {
        this.dy = dy;
    }

    public double getDz() {
        return dz;
    }

    public void setDz(double dz) {
        this.dz = dz;
    }
    
    public void abre(){
	if(aberta == false){
            aberta = true;
            System.out.println("A PORTA FOI ABERTA");
	}
    }
    public void fecha(){
	if(aberta == true){
            aberta = false;
            System.out.println("A PORTA FOI FECHADA");
	}
    }
    public void pinta(){
	cor = "AMARELO";
    }
    public void estaberta(){
	if(aberta == true){
		System.out.println("A porta está ABERTA");
	}else{
		System.out.println("A porta está FECHADA"); 
        }
    }
}
