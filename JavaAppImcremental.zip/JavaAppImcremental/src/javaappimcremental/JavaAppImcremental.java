
package javaappimcremental;


public class JavaAppImcremental {

    
    public static void main(String[] args) {
        /*Porta porta1 = new Porta();
        porta1.setAberta(Boolean.TRUE);
        porta1.setAberta(Boolean.FALSE);
        porta1.setCor("Verde");
        porta1.setDx(0.80);
        porta1.setDy(2.0);
        porta1.setDz(0.7);*/
     
        Casa casa1 = new Casa();
        casa1.setCor("Branca");
        Porta porta1casa = new Porta();
        porta1casa.setCor("verde");
        
        //System.out.println(casa1.getPorta1());
        
        
    }
    
}
