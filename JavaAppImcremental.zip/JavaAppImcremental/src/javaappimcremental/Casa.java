
package javaappimcremental;

public class Casa {
    private String cor;
    private String porta1;
    private String porta2;
    private String porta3;

    public String getCor() {
        return cor;
    }
    
    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPorta1() {
        return porta1;
    }

    public void setPorta1(String porta1) {
        this.porta1 = porta1;
    }

    public String getPorta2() {
        return porta2;
    }

    public void setPorta2(String porta2) {
        this.porta2 = porta2;
    }

    public String getPorta3() {
        return porta3;
    }

    public void setPorta3(String porta3) {
        this.porta3 = porta3;
    }
    
    public void pinta (String s){
    }
    public void quantPortaAbert(){
    }
    public int totalPortas(){
        return 0;
    }

}    