
package javaappimcremental;


public class Edificio {
    private String cor;
    private String totalDePortas;
    private String totalDeAndraderes;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTotalDePortas() {
        return totalDePortas;
    }

    public void setTotalDePortas(String totalDePortas) {
        this.totalDePortas = totalDePortas;
    }

    public String getTotalDeAndraderes() {
        return totalDeAndraderes;
    }

    public void setTotalDeAndraderes(String totalDeAndraderes) {
        this.totalDeAndraderes = totalDeAndraderes;
    }
   
    public void pintar(String s){    
    }
  //public int quantPortasAbertas(int q){
    public void adicionarPorta(Porta p){
    }
  //public int getquantidadeDePortas(){
  //}
    //return quantidadeDePortas()
    
}